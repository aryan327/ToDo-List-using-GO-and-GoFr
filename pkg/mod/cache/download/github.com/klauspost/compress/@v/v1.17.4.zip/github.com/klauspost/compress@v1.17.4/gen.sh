#!/bin/sh

cd s2/cmd/_s2sx/ || exit 1
go generate .
